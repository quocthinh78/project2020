<template>
    <div>
        day la trang service
        <router-view class="view two" name="d"></router-view>
        
    </div>
    
   
</template>

<script>
    export default {
        // beforeRouteEnter(to, from, next) {
        //     console.log("from" , from);
        //     console.log("to" ,  to);
        // }
    }
</script>