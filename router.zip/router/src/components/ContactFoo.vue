<template>
    <div>
        day la tran /contact/foo
    </div>
    
   
</template>