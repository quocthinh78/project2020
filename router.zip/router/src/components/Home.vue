<template>
    <div>
        day la tran /home
        <router-view class="view three" name="d"></router-view>
    </div>
    
   
</template>