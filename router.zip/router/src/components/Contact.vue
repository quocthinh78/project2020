<template>
     <div>
          day la contact
          <router-view></router-view>
        <router-view class="view three" name="d"></router-view>
     </div>
</template>