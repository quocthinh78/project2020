export default {
    user: null,
    password: null,
    destinations: [{
            "id": "1584177315024",
            "email": "trdbau@gmail.com",
            "password": "123456",
            "token": "1584177315024",
            "name": "toan"
        },
        {
            "id": "1584177319076",
            "email": "minhanh1306@gmail.com",
            "password": "123456",
            "token": "1584177319076",
            "name": "thinh"
        },
        {
            "id": "1584177319076",
            "email": "minhanh1306@gmail.com",
            "password": "123456",
            "token": "1584177319076",
            "name": "ngoc"
        }
    ]
}